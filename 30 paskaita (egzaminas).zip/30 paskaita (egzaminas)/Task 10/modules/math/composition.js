export function composition(a, b) {
  return a + b;
}
